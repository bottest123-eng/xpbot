// Required packages
const { Client, GatewayIntentBits, Partials, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");
const noblox = require("noblox.js");
const db = new QuickDB();

// Replace with your Roblox group ID
const GROUP_ID = 7812453;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

// XP Ranks
const ranks = [
  { name: "[N] Iniate", xp: 0 },
  { name: "[N] Vandalizer", xp: 10 },
  { name: "[N] Elite", xp: 25 },
  { name: "[N] Apex", xp: 40 },
  { name: "[N] Sentinel", xp: 60 },
  { name: "[N] Prime", xp: 75 },
  { name: "[N] Maiden", xp: 90 },
  { name: "[N] Demolition Monsignor", xp: 110 },
  { name: "[N] Dragoon", xp: 225 },
];

// Manual rank path (officer + custom ranks)
const manualRanks = [
  "[C] Herald", "[C] Warlords", "[C] Guardian", "[C] Centurion", "[C] Valkyrie",
  "[HC] Zypherion", "[HC] Captain", "[HC] Auxiliary",
  "[V] Overlord", "[V] Veteran", "Watchmans",
  "[O] Chief Warden", "[O] Quartermaster",
  "Battle Archivist", "[COM] Commandant"
];

// Get rank from XP
function getRank(xp) {
  let rank = ranks[0];
  for (let i = 0; i < ranks.length; i++) {
    if (xp >= ranks[i].xp) rank = ranks[i];
  }
  return rank;
}

// Get next XP-based rank
function getNextRank(xp) {
  return ranks.find((r) => r.xp > xp);
}

// Get current and next manual rank
function getManualRank(member) {
  for (let rank of manualRanks) {
    if (member.roles.cache.some(r => r.name === rank)) {
      const currentIndex = manualRanks.indexOf(rank);
      return {
        current: rank,
        next: manualRanks[currentIndex + 1] || null
      };
    }
  }
  return null;
}

client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;
  if (!message.content.startsWith("!")) return;

  const args = message.content.slice(1).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // ADD XP
  if (command === "add") {
    const mentions = message.mentions.users;
    const amount = parseInt(args[args.length - 1]);
    if (mentions.size === 0 || isNaN(amount)) return message.reply("Usage: !add @user1 @user2 amount");

    mentions.forEach(async user => await db.add(`xp_${user.id}`, amount));
    return message.reply(`✅ Added ${amount} XP to ${mentions.map(u => u.username).join(", ")}`);
  }

  // REMOVE XP
  if (command === "remove") {
    const mentions = message.mentions.users;
    const amount = parseInt(args[args.length - 1]);
    if (mentions.size === 0 || isNaN(amount)) return message.reply("Usage: !remove @user1 @user2 amount");

    mentions.forEach(async user => await db.sub(`xp_${user.id}`, amount));
    return message.reply(`✅ Removed ${amount} XP from ${mentions.map(u => u.username).join(", ")}`);
  }

  // XP VIEW
  if (command === "xp") {
    const user = message.mentions.members.first() || message.member;
    const manual = getManualRank(user);

    if (manual) {
      const embed = new EmbedBuilder()
        .setTitle(`${user.user.username}'s XP`)
        .setColor("Green")
        .addFields(
          { name: "Rank", value: manual.current, inline: true },
          { name: "Next Rank", value: manual.next || "Max", inline: true }
        );
      return message.reply({ embeds: [embed] });
    }

    let xp = await db.get(`xp_${user.id}`) || 0;
    const currentRank = getRank(xp);
    const nextRank = getNextRank(xp);
    const progress = nextRank ? Math.floor((xp - currentRank.xp) / (nextRank.xp - currentRank.xp) * 100) : 100;

    const embed = new EmbedBuilder()
      .setTitle(`${user.user.username}'s XP`)
      .setColor("Blue")
      .addFields(
        { name: "Rank", value: currentRank.name, inline: true },
        { name: "XP", value: `${xp}`, inline: true },
        { name: "Next Rank", value: nextRank ? nextRank.name : "Max", inline: true },
        { name: "Progress", value: `${progress}%`, inline: true }
      );

    return message.reply({ embeds: [embed] });
  }

  // RANK LIST
  if (command === "ranklist") {
    const list = ranks.map(r => `${r.name} - ${r.xp} XP`).join("\n");
    const embed = new EmbedBuilder()
      .setTitle("XP Rank List")
      .setColor("Blue")
      .setDescription(list);
    return message.reply({ embeds: [embed] });
  }

  // OFFICER RANK LIST
  if (command === "officerranklist") {
    const list = manualRanks.map((r, i) => `${i + 1}. ${r}`).join("\n");
    const embed = new EmbedBuilder()
      .setTitle("Officer Rank List")
      .setColor("Gold")
      .setDescription(list);
    return message.reply({ embeds: [embed] });
  }
});

// Bot ready
client.once("ready", () => {
  console.log(`Bot ready as ${client.user.tag}`);
});

client.login("MTM2NzQ1MDgyNjQ1NjU2Nzg3OQ.GWr7hI.fgPL3yl7VqvxU_CH4N0ZkXGOVUaR4_t40DHyAY"); // Replace with your actual bot token
